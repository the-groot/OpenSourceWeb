document.write("This is Outside JavaScript!");

